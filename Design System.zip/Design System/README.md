# Design System (v0.1 - tokens only)

HTML + CSS tokens, trích từ Figma Design System. Dùng để gen prototype nhanh. Components chưa build (chờ yêu cầu).

## Cấu trúc
- `tokens/primitives.css` – Color Global (light/dark/overlay, 778 biến, alpha giữ nguyên dạng rgba)
- `tokens/theme.css` – Semantic tokens (surface, fill, content, border, gradient, effect, custom) cho Light (mặc định) và Dark
- `tokens/dimension.css` – `--dm-*` (1 = 8px), `--space-*`, `--radius-*` (Standard mặc định, Smooth qua `data-radius="smooth"`)
- `tokens/typography.css` – font, size, line-height, letter-spacing; scale Base 14–28 và platform iOS/Android
- `tokens/elevation.css` – `--shadow-1..5`, `--focus-ring` (offset/blur là đề xuất)
- `index.html` – style guide tokens, có công tắc Theme / Radius / Type scale / Platform

## Dùng trong prototype
```html
<html lang="vi" data-theme="light">  <!-- light | dark -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="tokens/primitives.css">
<link rel="stylesheet" href="tokens/theme.css">
<link rel="stylesheet" href="tokens/dimension.css">
<link rel="stylesheet" href="tokens/typography.css">
<link rel="stylesheet" href="tokens/elevation.css">
```
Tuỳ chọn trên `<html>`: `data-theme`, `data-radius="smooth"`, `data-type-scale="14|18|20|24|28"` (mặc định 16), `data-platform="ios|android"`.

## Icon
- `icons/svg/{tên}.svg` – 150 icon dạng glass, lưới 24×24 (ví dụ `icons/svg/printer.svg`)
- `icons/icons.js` – toàn bộ icon dạng chuỗi SVG; gọi `dsIcon("printer", 24)` để lấy SVG inline (tự đổi id, dùng nhiều lần trên một trang vẫn đúng)
```html
<img src="icons/svg/printer.svg" width="24" height="24" alt="In">
<script src="icons/icons.js"></script>
```
Cỡ chuẩn: 16, 20, 24, 32, 40. Icon có màu cố định, cần đặt trên nền sáng.

### Icon UI (một màu, dùng cho giao diện)
- `icons/ui/18/{tên}.svg` – 884 icon lưới 18×18 (outline, solid, duotone; xem kiểu của từng icon trong portal)
- `icons/ui/12/{tên}.svg` – 140 icon lưới 12×12
- `icons/ui-icons.js` – gọi `dsUiIcon("magnifier", 18)`; icon dùng `currentColor`, đặt màu bằng token content (`color: var(--content-secondary)`)
```html
<script src="icons/ui-icons.js"></script>
```

## Quy tắc
1. Khi build component, chỉ dùng semantic token (`--fill-*`, `--content-*`, `--border-*`, `--surface-*`), không dùng hex hay primitive.
2. Spacing/size dùng `--dm-*` hoặc `--space-*`; bo góc dùng `--radius-*`.
3. Màu thương hiệu = yellow (`--fill-theme-default` #FFCB00), chữ trên nền theme dùng `--content-theme-primary`.
4. Brand biến thể: `--custom-lotus-*`, `--custom-vin33-*` (chỉ dùng khi làm theme đó).

## Giả định cần xác nhận
- Shadow: màu lấy từ `effect/elevation`, offset/blur tự đặt. Cần trang Elevation để đối chiếu.
- Icon set chưa có. Gửi SVG để đóng gói sprite.
